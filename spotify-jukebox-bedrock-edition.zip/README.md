# Spotify Jukebox — Minecraft Bedrock Edition

Este archivo contiene el behavior pack, el resource pack de audio y el companion de Spotify.

## Contenido
- `behavior_pack/`: script del complemento.
- `resource_pack/`: paquete de recursos de audio.
- `companion/`: puente de control con Spotify.

## Audio dentro del juego
La API de Spotify controla la reproducción, pero no transmite canciones de Spotify a Minecraft. Para oír sonido dentro del juego, añade un OGG autorizado llamado `spotify_jukebox.ogg` en `resource_pack/sounds/music/spotify_jukebox.ogg` y activa el resource pack y el behavior pack en el mundo.

## Instalación básica
1. En `companion/`, ejecuta `npm install`.
2. Configura `SPOTIFY_CLIENT_ID` y arranca `node server.js`.
3. Copia `behavior_pack/` a la carpeta de development behavior packs y `resource_pack/` a development resource packs.
4. Activa ambos packs en la configuración del mundo.

## Compatibilidad
`@minecraft/server-net` no está disponible en todos los entornos de Bedrock retail. El código debe probarse con tu versión y tipo de servidor.
