import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { http, HttpRequestMethod } from "@minecraft/server-net";

// Si el companion está en otro equipo, cambia localhost por su IP/dominio.
const SERVER_URL = "http://localhost:3001/jukebox-action";
const GAME_SOUND = "spotify_jukebox:music";
const ACTIONS = ["toggle", "next", "previous", "volume_up", "volume_down"];

world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
  if (ev.block.typeId !== "minecraft:jukebox") return;
  const player = ev.player;
  if (!player.isSneaking) {
    // Audio local del paquete de recursos: requiere instalar un archivo OGG propio.
    system.run(() => {
      try { player.playSound(GAME_SOUND, { volume: 1, pitch: 1 }); } catch {}
    });
    sendAction("toggle", player);
    return;
  }
  ev.cancel = true;
  system.run(() => openMenu(player));
});

function sendAction(action, player) {
  http.request(SERVER_URL, {
    method: HttpRequestMethod.POST,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, player: player.name })
  }).then((r) => {
    if (r.status === 200) player.sendMessage("§a[Spotify Jukebox] Orden enviada.");
    else player.sendMessage("§c[Spotify Jukebox] Error del companion (" + r.status + ").");
  }).catch(() => player.sendMessage("§c[Spotify Jukebox] No se pudo conectar al companion."));
}

function openMenu(player) {
  new ActionFormData().title("Spotify Jukebox")
    .button("⏯ Play / Pausa").button("⏭ Siguiente").button("⏮ Anterior")
    .button("🔊 Volumen +").button("🔉 Volumen -")
    .show(player).then(r => {
      if (!r.canceled) sendAction(ACTIONS[r.selection], player);
    });
}
